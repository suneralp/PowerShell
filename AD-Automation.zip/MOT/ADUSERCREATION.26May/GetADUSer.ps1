﻿

$users = Get-Content C:\Users\alp\PowerShell\ADUSERCREATION\deleteuser.txt
foreach ($user in $users) { 

#$result = get-ADUser -Identity $user -Property *|  Select de,distinguishedname,samAccountName,UserPrincipalName,FirstName,LastName,GivenName,Surname,DisplayName,Enabled,MIDepartmentt,MILocation,Division,Company,StartDatee,JobStatus,Jobcode,HRJobTitle,SupervisorID,SupervisorDNN,AccountOU,MailAlias,PersonalEmail,SupervisorEmail | Out-String

#$result = get-ADUser -Identity $user -Property *| select objectClass,	cn,	sn,	l,	st,	street,	ou,	title,	description,postalCode,	physicalDeliveryOfficeName,	givenName,	distinguishedName,	instanceType,	whenCreated,	whenChanged,	displayName,	uSNCreated,	memberOf,	uSNChanged,	co,	department,	company,	streetAddress,	employeeNumber,	employeeType,	name,	objectGUID,	userAccountControl,	badPwdCount,	codePage,	countryCode,	employeeID,	badPasswordTime,	lastLogoff,	lastLogon,	pwdLastSet,	primaryGroupID,	objectSid,	accountExpires,	logonCount,	sAMAccountName,	division,	sAMAccountType,	userPrincipalName,	lockoutTime,	objectCategory,	dSCorePropagationData,	lastLogonTimestamp,	mail,	manager,	departmentNumber,	extensionAttribute1,	extensionAttribute10,	extensionAttribute11| Out-String

$result = get-ADUser -Identity $user -Property *| select company,EmployeeNumber,name,EmployeeID,sAMAccountName,division, UserPrincipalName,manager| Out-String

write-host -foregroundcolor Cyan $result

}


