﻿Import-Module ActiveDirectory

#New-ADUser -Name "Jason Bourne" -Path "OU=MOT,OU=USER,DC=MYLAB,DC=LOCAL" `
# -GivenName "Jason" -Surname "Bourne" -SamAccountName "Jason-Bourne" `
# -AccountPassword (ConvertTo-SecureString -AsPlainText “webdir123Rwebdir123R” -Force ) `
# -ChangePasswordAtLogon $True -DisplayName "Jason Bourne" -Enabled $True `
# -OtherAttributes @{'HrJobTitle'="director";'MILocation'="MA12";'MIDepartment'="TX12"}



     New-ADUser -NAme glenJohn `
     -SamAccountName "glenjohn" `
       -GivenName "Glen" -Surname "John" ` 
        -Path 'OU=MOT,OU=USER,DC=MYLAB,DC=LOCAL' `
         -OtherAttributes @{'MIDepartment'="MI12"} `
  

  set-ADUser M0032756 -Add @{MILocation="AL00";MIDepartmentt="NY29"}