﻿# Import active directory module for running AD cmdlets
Import-Module ActiveDirectory
  
# Store the data from NewUsersFinal.csv in the $ADUsers variable
$ADUsers = Import-Csv C:\Users\alp\PowerShell\ADUSERCREATION\NewAccounts_20230517_041621AM.csv -Delimiter ","

# Define UPN
$UPN = "mylab.local"   ### should be changed before deploying on PROD

# Loop through each row containing user details in the CSV file
foreach ($User in $ADUsers) {

    #Read user data from each field in each row and assign the data to a variable as below
    $username = $User.SamAccountName
    $password = $User.password
    $firstname = $User.firstname
    $lastname = $User.lastname
    $OU = $User.ou                  #### can we get this information as $OU variable in existing creation CSV file with seperate column?    ####
    $EmployeeID = $User.employeeID
    $UserPrincipalName = $User.UserPrincipalName
    $MIDepartment = $User.MIDepartment
    $MILocation = $User.MILocation
    $Division = $User.Division
    $Company = $User.Company
    $JobStatus = $User.JobStatus
    $MILocation = $User.MILocation
    $JobCode = $User.JobCode
    $HRJobTitle = $User.HRJobTitle
    $SuperVisorID = $User.SuperVisorID
    $SuperVisorDNN = $User.SuperVisorDNN
    $StartDatee = $User.StartDatee
    $MIDepartmentt = $User.MIDepartmentt
    $AccountOU = $User.AccountOU
    $MailAlias = $User.MailAlias
    $PersonalEmail = $User.PersonalEmail
    $SupervisorEmail = $User.SupervisorEmail


 
      # Check to see if the user already exists in AD
    if (Get-ADUser -F { SamAccountName -eq $username }) {
        
        # If user exist, give a warning
        Write-Warning "A user account with username $username already exists in Active Directory."
    }
    else {

        # User does not exist then proceed to create the new user account
        # Account will be created in the OU provided by the $OU variable read from the CSV file

       New-ADUser `
            -SamAccountName $username `
            -UserPrincipalName "$UserPrincipalName" `
            -Name "$firstname $lastname" `
            -GivenName $firstname `
            -Surname $lastname `
            -AccountPassword (ConvertTo-secureString $password -AsPlainText -Force) -ChangePasswordAtLogon $True `
            -EmployeeID $EmployeeID `
            -Enabled $True `
            -Path $OU `
            -DisplayName "$firstname $lastname" `
            -Division $Division `
            -Company $Company `
                    
        # If user is created, show message.
        Write-Host "The user account $username is created." -ForegroundColor Cyan


       #  Update Custom Attributes with the values from CSV file as it is not possible with "New-ADUser" command
        
            
            Get-ADUser -Identity $Username| Set-ADUser -Add @{FirstName=$FirstName}
            Get-ADUser -Identity $Username| Set-ADUser -Add @{LastName=$LastName}
            Get-ADUser -Identity $Username| Set-ADUser -Add @{MIDepartmentt=$MIDepartmentt}      # SHOULD BE RENAMED AS "MIDepartment" on Prod !
            Get-ADUser -Identity $Username| Set-ADUser -Add @{MILocation=$MILocation}
            Get-ADUser -Identity $Username| Set-ADUser -Add @{StartDatee=$StartDatee}            # SHOULD BE RENAMED AS "StartDate" on Prod !
            Get-ADUser -Identity $Username| Set-ADUser -Add @{JobStatus=$JobStatus}
            Get-ADUser -Identity $Username| Set-ADUser -Add @{JobCode=$JobCode}
            Get-ADUser -Identity $Username| Set-ADUser -Add @{HRJobTitle=$HRJobTitle}
            Get-ADUser -Identity $Username| Set-ADUser -Add @{SuperVisorID=$SuperVisorID}
            Get-ADUser -Identity $Username| Set-ADUser -Add @{SuperVisorDNN=$SuperVisorDNN}     # SHOULD BE RENAMED AS "SuperVisorDN" on Prod !
            Get-ADUser -Identity $Username| Set-ADUser -Add @{AccountOU=$AccountOU}
            Get-ADUser -Identity $Username| Set-ADUser -Add @{MailAlias=$MailAlias}
            Get-ADUser -Identity $Username| Set-ADUser -Add @{PersonalEmail=$PersonalEmail}
            Get-ADUser -Identity $Username| Set-ADUser -Add @{SupervisorEmail=$SupervisorEmail}  
                  `
      }
}


#Read-Host -Prompt "Press Enter to exit"
