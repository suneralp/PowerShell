﻿Import-Module ActiveDirectory
  
$ADUsers = Import-Csv C:\Users\alp\PowerShell\ADUSERCREATION\NewAccounts_20230517_041621AM2.csv -Delimiter ","
$UPN = "mylab.local"   ### should be changed before deploying on PROD

foreach ($User in $ADUsers) {

    $username = $User.SamAccountName
    $password = $User.password
    $firstname = $User.firstname
    $lastname = $User.lastname
    $OU = $User.ou                  #### can we get this information as $OU variable in existing creation CSV file with seperate column?    ####
    $EmployeeID = $User.employeeID
    $UserPrincipalName = $User.UserPrincipalName
    $MIDepartment = $User.MIDepartment
    $MILocation = $User.MILocation
    $Division = $User.Division
    $Company = $User.Company
    $JobStatus = $User.JobStatus
    $MILocation = $User.MILocation
    $JobCode = $User.JobCode
    $HRJobTitle = $User.HRJobTitle
    $SuperVisorID = $User.SuperVisorID
    $SuperVisorDNN = $User.SuperVisorDNN
    $StartDatee = $User.StartDatee
    $MIDepartmentt = $User.MIDepartmentt
    $AccountOU = $User.AccountOU
    $MailAlias = $User.MailAlias
    $PersonalEmail = $User.PersonalEmail
    $SupervisorEmail = $User.SupervisorEmail

      if (Get-ADUser -F { SamAccountName -eq $username }) {
        
        Write-Warning "A user account with username $username already exists in Active Directory."
    }
    else {

         New-ADUser `
            -SamAccountName $username `
            -UserPrincipalName "$UserPrincipalName" `
            -Name "$firstname $lastname" `
            -GivenName $firstname `
            -Surname $lastname `
            -AccountPassword (ConvertTo-secureString $password -AsPlainText -Force) -ChangePasswordAtLogon $True `
            -EmployeeID $EmployeeID `
            -Enabled $True `
            -Path $OU `
            -DisplayName "$firstname $lastname" `
            -Division $Division `
            -Company $Company `
                   
           Write-Host "The user account $username is created." -ForegroundColor Cyan 
            
            Get-ADUser -Identity $Username| Set-ADUser -Add @{FirstName=$FirstName}
            Get-ADUser -Identity $Username| Set-ADUser -Add @{LastName=$LastName}
            Get-ADUser -Identity $Username| Set-ADUser -Add @{MIDepartmentt=$MIDepartmentt}      # SHOULD BE RENAMED AS "MIDepartment" on Prod !
            Get-ADUser -Identity $Username| Set-ADUser -Add @{MILocation=$MILocation}
            Get-ADUser -Identity $Username| Set-ADUser -Add @{StartDatee=$StartDatee}            # SHOULD BE RENAMED AS "StartDate" on Prod !
            Get-ADUser -Identity $Username| Set-ADUser -Add @{JobStatus=$JobStatus}
            Get-ADUser -Identity $Username| Set-ADUser -Add @{JobCode=$JobCode}
            Get-ADUser -Identity $Username| Set-ADUser -Add @{HRJobTitle=$HRJobTitle}
            Get-ADUser -Identity $Username| Set-ADUser -Add @{SuperVisorID=$SuperVisorID}
            Get-ADUser -Identity $Username| Set-ADUser -Add @{SuperVisorDNN=$SuperVisorDNN}     # SHOULD BE RENAMED AS "SuperVisorDN" on Prod !
            Get-ADUser -Identity $Username| Set-ADUser -Add @{AccountOU=$AccountOU}
            Get-ADUser -Identity $Username| Set-ADUser -Add @{MailAlias=$MailAlias}
            Get-ADUser -Identity $Username| Set-ADUser -Add @{PersonalEmail=$PersonalEmail}
            Get-ADUser -Identity $Username| Set-ADUser -Add @{SupervisorEmail=$SupervisorEmail}  
                  `
      }
}

