﻿
$users = Get-Content C:\Users\alp\PowerShell\ADUSERCREATION\deleteuser.txt
foreach ($user in $users) { 
Remove-ADUser -Identity $user -Confirm:$false 
Write-Host "The user account $user is deleted. " -ForegroundColor Cyan 
}