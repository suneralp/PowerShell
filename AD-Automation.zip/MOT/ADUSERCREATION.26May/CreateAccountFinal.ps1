﻿Import-Module activedirectory

$UPN = "mylab.local" 
$ADUsers = Import-Csv C:\Users\alp\PowerShell\ADUSERCREATION\NewAccounts_20230517_041621AM.csv  -Delimiter ","

foreach ($User in $ADUsers)
{

$Username = $User.username
$Password = $User.password
$Firstname = $User.firstname
$Lastname = $User.lastname
$Division = $User.Division
$Company = $User.Company
$OU = $User.OU
$SuperVisorID = $User.SuperVisorID
 
if (Get-ADUser -F {SamAccountName -eq $Username})
{
Write-Warning "A user account with username $Username already exists in Active Directory."
}
else
{
New-ADUser `
  -SamAccountName $Username `
  -UserPrincipalName "$username@$UPN" `
  -Name "$Firstname $Lastname" `
  -EmployeeNumber $Username `
  -GivenName $Firstname `
  -Surname $Lastname `
  -AccountPassword (ConvertTo-secureString $password -AsPlainText -Force) -ChangePasswordAtLogon $True `
  -EmployeeID $username `
  -Enabled $True `
  -Path $OU `
  -DisplayName "$firstname $lastname" `
  -Division $Division `
  -Company $Company `
  -Manager $SuperVisorID
          
                       
 Write-Host "The user account $username is created." -ForegroundColor Cyan 

 }
}

             