#!/usr/bin/env pwsh

$Env:PATH += ";C:\Program Files\PowerShell\7;C:\Users\PCTR896541\PowerShell"


Function Menu 
{
    Clear-Host        
    Do
    {
        #Clear-Host                                                                       
        Write-Host -Object 'Please choose an option'
        Write-Host     -Object '**********************'
        Write-Host -Object 'AD Operations Menu' -ForegroundColor Yellow
        Write-Host     -Object '**********************'
        Write-Host -Object '1.  GetADUsers '
    Write-Host -Object ''
        Write-Host -Object '2.  GetADUsers with Name '
    Write-Host -Object ''
    Write-Host -Object '3.  GetADUsers with AllAttr '
    Write-Host -Object ''
	Write-Host -Object '4.  GetADUsers with specific Attr'
    Write-Host -Object ''
	Write-Host -Object '5.  Find All Locked User Accounts'
    Write-Host -Object ''
	Write-Host -Object '6.  Find All User Accounts whose passwords never expire'
    Write-Host -Object ''
	Write-Host -Object '7.  Get AD Group Name Information'
    Write-Host -Object ''
	Write-Host -Object '8.  Get AD Group Member Information'
    Write-Host -Object ''
	Write-Host -Object '9.  Get Account Expiration Time'
    Write-Host -Object ''
	
        Write-Host -Object 'Q.  Quit'
        Write-Host -Object $errout
        $Menu = Read-Host -Prompt '(0-8 or Q to Quit)'
 
        switch ($Menu) 
        {
           1 
            {
              #1.ps1                   
              PowerShell.exe -command "C:\Users\PCTR896541\PowerShell\getADUser.ps1"
              cmd /c pause 
            }
			
            2 
            {
               PowerShell.exe -command "C:\Users\PCTR896541\PowerShell\getADUserLike.ps1"
              cmd /c pause 
            }
			
            3 
            {
                PowerShell.exe -command "C:\Users\PCTR896541\PowerShell\getADUserWithAttr.ps1"
              cmd /c pause
            }
			
			4 
            {
                PowerShell.exe -command "C:\Users\PCTR896541\PowerShell\getADUserWithSpcAttr.ps1"
              cmd /c pause
            }
			
			5 
            {
                PowerShell.exe -command "C:\Users\PCTR896541\PowerShell\FindAllLockedUserAccounts.ps1"
              cmd /c pause
            }
			
			6 
            {
                PowerShell.exe -command "C:\Users\PCTR896541\PowerShell\NeverExpireUsers.ps1"
              cmd /c pause
            }
			
			7 
            {
                PowerShell.exe -command "C:\Users\PCTR896541\PowerShell\GetADGroup.ps1"
              cmd /c pause
            }
			
			8 
            {
                PowerShell.exe -command "C:\Users\PCTR896541\PowerShell\GetADGroupMember.ps1"
              cmd /c pause
            }
			
		   9 
            {
                PowerShell.exe -command "C:\Users\PCTR896541\PowerShell\getADUserExpTme.ps1"
             cmd /c pause
            }
            Q 
            {
                Exit
            }   
            default
            {
                $errout = 'Invalid option please try again........Try 0-4 or Q only'
            }
 
        }
    }
    until ($Menu -eq 'q')
}   
 
# Launch The Menu
Menu

#'userAccountControl