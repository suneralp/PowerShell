Import-Module ActiveDirectory
  
$ADUsers = Import-Csv C:\Users\alp\PowerShell\ADUSERCREATION\NewAccounts_20230517_041621AM.csv -Delimiter ","
$UPN = "mylab.local"   ### should be changed before deploying on PROD

foreach ($User in $ADUsers) {

    $username = $User.SamAccountName
    $password = $User.password
    $OU = $User.ou                  
    $EmployeeID = $User.SamAccountName
    $Division = $User.Division
    $Company = $User.Company
    

      if (Get-ADUser -F { SamAccountName -eq $username }) {
        
        Write-Warning "A user account with username $username already exists in Active Directory."
    }
    else {

         New-ADUser `
            -SamAccountName $username `
            -EmployeeID $SamAccountName `
            -UserPrincipalName "$EmployeeID@$UPN" `
            -AccountPassword (ConvertTo-secureString $password -AsPlainText -Force) -ChangePasswordAtLogon $True `
           ` -Enabled $True `
            -Path $OU `
            -Division $Division `
            -Company $Company `
                   
           Write-Host "The user account $username is created." -ForegroundColor Cyan 
          }  
        
                  `
      
}

